import 'dart:async';
import 'package:flutter/material.dart';
import 'package:camera/camera.dart';
import 'person_tracker.dart';
import 'line_crossing.dart';
import 'yolo_detector.dart';
import 'camera_service.dart';

class LiveDetectionScreen extends StatefulWidget {
  const LiveDetectionScreen({super.key});

  @override
  State<LiveDetectionScreen> createState() => _LiveDetectionScreenState();
}

class _LiveDetectionScreenState extends State<LiveDetectionScreen> {
  final CameraService _cameraService = CameraService();
  final YoloDetector _detector = YoloDetector();
  late PersonTracker _tracker;
  late LineCrossingDetector _crossingDetector;

  bool _isDetecting = false;
  bool _isProcessingFrame = false;
  String _selectedDoor = 'Front';
  List<Detection> _latestDetections = [];
  String? _errorMessage;

  @override
  void initState() {
    super.initState();
    _tracker = PersonTracker();
    _crossingDetector = LineCrossingDetector(tracker: _tracker);
    _initialize();
  }

  Future<void> _initialize() async {
    try {
      await _detector.loadModel();
    } catch (e) {
      setState(() {
        _errorMessage = 'Failed to load model: $e';
      });
      return;
    }

    try {
      await _cameraService.initializeCameras();
      await _cameraService.startCamera();
    } catch (e) {
      setState(() {
        _errorMessage = 'Failed to start camera: $e';
      });
      return;
    }

    if (mounted) setState(() {});
    _startDetection();
  }

  void _startDetection() {
    _isDetecting = true;
    _cameraService.frameStream.listen((CameraFrame frame) {
      if (!_isDetecting || _isProcessingFrame) return;

      _processFrame(frame);
    });
  }

  Future<void> _processFrame(CameraFrame frame) async {
    _isProcessingFrame = true;

    try {
      final detections = _detector.runInference(
        frame.bytes,
        width: frame.width,
        height: frame.height,
      );

      _tracker.update(detections);
      _crossingDetector.processFrame();

      _latestDetections = detections;

      if (mounted) {
        setState(() {});
      }
    } catch (e) {
      debugPrint('Frame processing error: $e');
    } finally {
      _isProcessingFrame = false;
    }
  }

  void _resetCounters() {
    _tracker.reset();
    _crossingDetector.reset();
    _latestDetections = [];
    setState(() {});
  }

  @override
  void dispose() {
    _cameraService.dispose();
    _detector.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        fit: StackFit.expand,
        children: [
          if (_errorMessage != null)
            Center(
              child: Container(
                padding: const EdgeInsets.all(24),
                margin: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  color: Colors.red.withValues(alpha: 0.2),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.error, color: Colors.red, size: 48),
                    const SizedBox(height: 16),
                    Text(
                      _errorMessage!,
                      style: const TextStyle(color: Colors.red, fontSize: 16),
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
              ),
            )
          else if (_cameraService.isInitialized)
            SizedBox.expand(
              child: FittedBox(
                fit: BoxFit.cover,
                child: SizedBox(
                  width: _cameraService.controller!.value.previewSize?.height ??
                      MediaQuery.of(context).size.width,
                  height: _cameraService.controller!.value.previewSize?.width ??
                      MediaQuery.of(context).size.height,
                  child: CameraPreview(_cameraService.controller!),
                ),
              ),
            )
          else
            const Center(
              child: CircularProgressIndicator(color: Colors.white),
            ),

          CustomPaint(
            size: Size.infinite,
            painter: _OverlayPainter(
              linePosition: _crossingDetector.linePosition,
              detections: _latestDetections,
            ),
          ),

          Positioned(
            top: MediaQuery.of(context).padding.top + 16,
            left: 16,
            right: 16,
            child: _buildStatsPanel(),
          ),

          Positioned(
            bottom: MediaQuery.of(context).padding.bottom + 16,
            left: 16,
            right: 16,
            child: _buildControlPanel(),
          ),
        ],
      ),
    );
  }

  Widget _buildStatsPanel() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.black.withValues(alpha: 0.7),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              _buildStatBox('Entries', _crossingDetector.entries, Colors.green),
              _buildStatBox('Exits', _crossingDetector.exits, Colors.red),
              _buildStatBox('Occupancy', _crossingDetector.occupancy, Colors.blue),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Text(
                'Door: ',
                style: TextStyle(color: Colors.white70, fontSize: 14),
              ),
              DropdownButton<String>(
                value: _selectedDoor,
                dropdownColor: Colors.grey[800],
                style: const TextStyle(color: Colors.white),
                underline: Container(),
                items: ['Front', 'Back'].map((String door) {
                  return DropdownMenuItem<String>(
                    value: door,
                    child: Text(door),
                  );
                }).toList(),
                onChanged: (String? newValue) {
                  setState(() {
                    _selectedDoor = newValue!;
                  });
                },
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildStatBox(String label, int value, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.2),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Column(
        children: [
          Text(
            value.toString(),
            style: TextStyle(
              color: color,
              fontSize: 24,
              fontWeight: FontWeight.bold,
            ),
          ),
          Text(
            label,
            style: const TextStyle(color: Colors.white70, fontSize: 12),
          ),
        ],
      ),
    );
  }

  Widget _buildControlPanel() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        ElevatedButton.icon(
          onPressed: _resetCounters,
          icon: const Icon(Icons.refresh),
          label: const Text('Reset'),
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.orange,
            foregroundColor: Colors.white,
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
          ),
        ),
        ElevatedButton.icon(
          onPressed: () {
            Navigator.pop(context);
          },
          icon: const Icon(Icons.stop),
          label: const Text('Stop'),
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.red,
            foregroundColor: Colors.white,
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
          ),
        ),
      ],
    );
  }
}

class _OverlayPainter extends CustomPainter {
  final double linePosition;
  final List<Detection> detections;

  _OverlayPainter({required this.linePosition, required this.detections});

  @override
  void paint(Canvas canvas, Size size) {
    final lineY = size.height * linePosition;

    // Draw Virtual Threshold Line
    final linePaint = Paint()
      ..color = Colors.yellow
      ..strokeWidth = 3
      ..style = PaintingStyle.stroke;

    canvas.drawLine(
      Offset(0, lineY),
      Offset(size.width, lineY),
      linePaint,
    );

    // Label: OUTSIDE (OUT) - Top side of line
    final outTextPainter = TextPainter(
      text: const TextSpan(
        text: '▲ OUTSIDE (OUT)',
        style: TextStyle(
          color: Colors.redAccent,
          fontSize: 13,
          fontWeight: FontWeight.bold,
          letterSpacing: 1.1,
        ),
      ),
      textDirection: TextDirection.ltr,
    );
    outTextPainter.layout();
    
    // Draw OUT background badge
    final outBgRect = RRect.fromRectAndRadius(
      Rect.fromLTWH(12, lineY - 28, outTextPainter.width + 16, 22),
      const Radius.circular(6),
    );
    final outBgPaint = Paint()
      ..color = Colors.black.withValues(alpha: 0.6)
      ..style = PaintingStyle.fill;
    canvas.drawRRect(outBgRect, outBgPaint);
    outTextPainter.paint(canvas, Offset(20, lineY - 24));

    // Label: INSIDE (IN) - Bottom side of line
    final inTextPainter = TextPainter(
      text: const TextSpan(
        text: '▼ INSIDE (IN)',
        style: TextStyle(
          color: Colors.greenAccent,
          fontSize: 13,
          fontWeight: FontWeight.bold,
          letterSpacing: 1.1,
        ),
      ),
      textDirection: TextDirection.ltr,
    );
    inTextPainter.layout();

    // Draw IN background badge
    final inBgRect = RRect.fromRectAndRadius(
      Rect.fromLTWH(12, lineY + 8, inTextPainter.width + 16, 22),
      const Radius.circular(6),
    );
    final inBgPaint = Paint()
      ..color = Colors.black.withValues(alpha: 0.6)
      ..style = PaintingStyle.fill;
    canvas.drawRRect(inBgRect, inBgPaint);
    inTextPainter.paint(canvas, Offset(20, lineY + 12));

    // Label: Center Threshold Title
    final lineTitlePainter = TextPainter(
      text: const TextSpan(
        text: '━━ DOORWAY THRESHOLD ━━',
        style: TextStyle(
          color: Colors.yellow,
          fontSize: 11,
          fontWeight: FontWeight.w600,
        ),
      ),
      textDirection: TextDirection.ltr,
    );
    lineTitlePainter.layout();
    lineTitlePainter.paint(canvas, Offset(size.width - lineTitlePainter.width - 16, lineY - 18));

    // Draw Bounding Boxes
    final boxPaint = Paint()
      ..color = Colors.greenAccent
      ..strokeWidth = 2.5
      ..style = PaintingStyle.stroke;

    final fillPaint = Paint()
      ..color = Colors.greenAccent.withValues(alpha: 0.18)
      ..style = PaintingStyle.fill;

    for (final det in detections) {
      final rect = Rect.fromLTRB(
        det.left * size.width,
        det.top * size.height,
        det.right * size.width,
        det.bottom * size.height,
      );
      canvas.drawRect(rect, fillPaint);
      canvas.drawRect(rect, boxPaint);

      final labelPainter = TextPainter(
        text: TextSpan(
          text: 'Person ${(det.confidence * 100).toInt()}%',
          style: const TextStyle(
            color: Colors.white,
            fontSize: 11,
            fontWeight: FontWeight.bold,
            backgroundColor: Colors.green,
          ),
        ),
        textDirection: TextDirection.ltr,
      );
      labelPainter.layout();
      labelPainter.paint(canvas, Offset(rect.left, rect.top - 14));
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}
